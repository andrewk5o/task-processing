const createTask = require('./createTask');
const getTasks = require('./getTasks');

module.exports = { createTask, getTasks };
